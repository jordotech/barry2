<footer<?php print $attributes; ?>>
  <?php print $content; ?>
</footer>